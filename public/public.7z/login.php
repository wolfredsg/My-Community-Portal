<div class="row"><p><br></p></div>
<div class="row">
    <div class="col-lg-7" style="height:580px;background-color: #FFF056;border-style: solid; border-color: #FFF056;border-width: 1px;">
        <h2>Welcome back member!</h2>
        <h4>Just log in below.</h4>
        <form action="./?home" method="post">
            <div class="form-group">
                <br>
                <label for="email">Username</label>
                <input type="email" name='email' class="form-control" id="email" placeholder="example@example.com">
            </div>
            <div class="form-group">
                <label for="pwd">Password</label>
                <input type="password" name='password' class="form-control" id="pwd" placeholder="Enter password">
            </div>
            <div><p style="text-decoration: underline;">Having trouble logging in? Reset.</p></div>
            <div class="checkbox">
                <label><input type="checkbox"> Remember me</label>
            </div>
            <input type="submit" class="btn btn-default" name='submit' value='Log In' />
            <div><br><p style="text-decoration: underline;"><a class="linkheader" href="./?registration" >Not a member yet? Sign up for free?</a></p></div>
        </form>
    </div>
    <div class="col-lg-5" style="height:580px;border-style:solid;background-color:#FFF056;border-color:#FFF056;border-width:5px;padding-top:3px;padding-right:3px;">
        <img class="img-responsive" style="width:100%;display:block;" src="image/login.png" alt="homepage">
    </div>
</div>
<div class="row"><p><br></p></div>


